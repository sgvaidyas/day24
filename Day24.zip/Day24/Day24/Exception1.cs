﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class Exception1
    {
        static void Main(string[] args)
        {
            int a, b,res;
            Console.WriteLine("ENTER A  AND B  = ");
            a = int.Parse(Console.ReadLine());
            b= int.Parse(Console.ReadLine());
            try
            {
                res = a / b;
                Console.WriteLine("RES = " + res);
            }
            catch(Exception)
            {
                Console.WriteLine("denominator is 0(Divide by Zero error)");
            }
                        
            Console.WriteLine("First line is here");
            Console.WriteLine("Second line is here");
        }
    }
}
