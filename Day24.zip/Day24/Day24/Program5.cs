﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class X
    {
        public virtual void dosomething()
        {
            Console.WriteLine("X --> do something");
        }
    }
    class Y : X
    {
        public sealed override void dosomething()
        {
            Console.WriteLine("Y --> do something");
        }
    }

    class Z:Y
    {
       /* public override void dosomething()
        {

        }
        */
    }

    class Program5
    {
    }
}
