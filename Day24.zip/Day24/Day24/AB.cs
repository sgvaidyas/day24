﻿using System;


namespace Day24
{
    class Myexception:Exception
    {
        public Myexception(String msg):base(msg)
        {
            Console.WriteLine("___________MY OWN EXCEPTION________________");
        }
    }
    internal class AB
    {
        public int score;
        public AB()
        {
            Console.WriteLine("Enter the score");
            score = int.Parse(Console.ReadLine());
        }
        public void eligible()
        {
            if (score < 60)
                throw new Myexception("Not eligible");
            else
                Console.WriteLine("Eligible");
        }
    }
}