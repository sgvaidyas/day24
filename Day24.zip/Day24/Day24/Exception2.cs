﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class Exception2
    {
        static void Main(string[] args)
        {
            string s;
            int ind;
            Console.WriteLine("ENTER A STRING = ");
            s = Console.ReadLine();

            Console.WriteLine("Enter the index to retrieve char");
            ind = int.Parse(Console.ReadLine());
            try
            {
                Console.WriteLine("the char at this index = {0} is {1}", ind, s[ind]);
            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine("Index is not available as the len of string is = "+s.Length);
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception = " + e);
            }
            Console.WriteLine("\n\n hey this is me ");
        }
    }
}
