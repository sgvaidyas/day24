﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class A
    {
        //overriding is applicable only to methods
        public string name = "A";
        public virtual void display()
        {
            Console.WriteLine("A class");
        }
    }
    class B : A
    {
        public string name = "B";
        public override void display()
        {
            Console.WriteLine("B class");
        }
    }
    class Program3
    {
        static void Main(string[] args)
        {
            A ob = new B();
            ob.display();
            Console.WriteLine(ob.name);
        }
    }
}
