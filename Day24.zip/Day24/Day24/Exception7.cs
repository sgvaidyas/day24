﻿using System;
using System.Text.RegularExpressions;

namespace Day24
{ 
    class Server
    {
        public string Servername { get; set; }
    }
    class MyExcept : Exception
    {
        public MyExcept(string s):base(String.Format("invalid Servername : {0}",s))
        {

        }
    }

    class Exception7
    {
        static void Valid(Server ob)
        {
            Regex regex = new Regex("^[a-zA-Z]{7}$");

            if (!regex.IsMatch(ob.Servername))
                throw new MyExcept(ob.Servername);
        }
        static void Main(string[] args)
        {
            Server ob = null;

            try
            {
                ob = new Server();
                Console.Write("Enter the server name = ");
                ob.Servername = Console.ReadLine();
                Valid(ob);
            }
            catch (MyExcept e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
