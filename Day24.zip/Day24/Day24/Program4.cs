﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class MusicPlayer
    {
        public string name, songid, songdur, singer;

        public MusicPlayer()
        {
            Console.WriteLine("ENTER NAME           = ");
            name = Console.ReadLine();
            Console.WriteLine("ENTER SONG ID        = ");
            songid = Console.ReadLine();
            Console.WriteLine("ENTER SONG DURATION  = ");
            songdur = Console.ReadLine();
            Console.WriteLine("ENTER SINGER         = ");
            singer = Console.ReadLine();
        }
        public virtual void display()
        {
            Console.WriteLine(name + " " + songid   + " " + songdur + " " + singer   );
        }
    }

    class VLC : MusicPlayer
    {
        public string playlistname, noofsongs;
        public VLC()
        {
            Console.WriteLine("ENTER PLAYLISTNAME   = ");
            playlistname = Console.ReadLine();
            Console.WriteLine("ENTER NOOFSONGS      = ");
            noofsongs = Console.ReadLine();
        }
        public override void display()
        {
            Console.WriteLine("\n__________________________\n");
            Console.WriteLine("NAME              = " + name);
            Console.WriteLine("SONGID            = " + songid);
            Console.WriteLine("SONG DURATION     = " + songdur);
            Console.WriteLine("SINGER            = " + singer);
            Console.WriteLine("PLAYLISTNAME      = " + playlistname);
            Console.WriteLine("NO OF SONGS       = " + noofsongs);
        }
    }
    
    class Program4
    {
        static void Main(string[] args)
        {
            MusicPlayer ob = new VLC();
            ob.display();
        }
    }
}
