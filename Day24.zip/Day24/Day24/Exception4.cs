﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class Exception4
    {
        static void Main(string[] args)
        {
            string s = null;
            Console.WriteLine("enter x");
            int x = int.Parse(Console.ReadLine());
            if (x >= 10)
                s = "SOMETHING";
            try
            {
                Console.WriteLine(s.Length);
            }
            catch(NullReferenceException)
            {
                Console.WriteLine("S is null");
            }
        }
    }
}
