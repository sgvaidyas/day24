﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class Exception5
    {
        static void Main(string[] args)
        {
            bool isvalid = true;

            string valid = isvalid.ToString();

            /*
            for(int i =350;i<400; i++)
                Console.WriteLine(Convert.ToChar(i));
                */
            
        }
    }
}
