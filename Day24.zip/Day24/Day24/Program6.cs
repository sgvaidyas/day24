﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    abstract class Student
    {
        public string name, id, coursename;
        public abstract void getdetails();
        public virtual void display()
        {
            Console.WriteLine("Student Details");
        }
    }

    class EngineeringStu : Student
    {
        public string coursecat, fees;
        public override void getdetails()
        {
            Console.WriteLine("NAME    = ");
            name = Console.ReadLine();
            Console.WriteLine("ID    = ");
            id = Console.ReadLine();
            Console.WriteLine("COURSENAME    = ");
            coursename = Console.ReadLine();
            Console.WriteLine("COURSECATEGORY    = ");
            coursecat = Console.ReadLine();
            Console.WriteLine("FEES    = ");
            fees = Console.ReadLine();
        }
        public override void display()
        {
            base.display();
            Console.WriteLine("NAME             =   " + name);
            Console.WriteLine("ID               =   " + id);
            Console.WriteLine("COURSENAME       =   " + coursename);
            Console.WriteLine("COURSECATEGORY   =   " + coursecat);
            Console.WriteLine("FEES             =   " + fees);

        }
    }
    class Program6
    {
        static void Main(string[] args)
        {
            Student ob = new EngineeringStu();
            ob.getdetails();
            ob.display();
        }
    }
}
