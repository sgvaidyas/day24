﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class Exception6cs
    {
        static void Main(string[] args)
        {
            try
            {
                AB ob = new AB();
                ob.eligible();
            }
            catch(Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
