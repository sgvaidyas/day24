﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day24
{
    class Fruits
    {
        private static int cnt;
        public string fname;

        public Fruits()
        {
            cnt++;
        }
        public static int Count
        {
            get
            {
                return cnt;
            }
        }
    }
    class Program2
    {
        static void Main(string[] args)
        {
            Fruits f1 = new Fruits();
            Fruits f2 = new Fruits();
            Fruits f3 = new Fruits();
            Console.WriteLine("NO of fruits created  =  " + Fruits.Count   );
         }
    }
}
